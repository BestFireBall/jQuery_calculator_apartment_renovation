var $rooms_count = 7,
	$toilets_count = 3,
	$coridors_count = 1,
	$kitchens_count = 1,
	$loggias_count = 2,
	$walls_height = $('.walls_height_input').val(),
	$windows_count = 3,
	$room_windows = [];

$(document).ready(function() {
	$('.apt_1').trigger('click');
	$('.toilet_1').trigger('click');
	$('.loggia_1').trigger('click');
	console.log('Recalculation by: document.ready');
	
	Recalc();
	recalcSquare();
});

// Click from-square
$('.from-square').on('click', function(){
	var $findSquare = $(this).parents('.eSquare1').find('.eSquare2').attr('value');
	console.log($findSquare);
	if(!$(this).hasClass('img-active')) $(this).parent().find('.digit-quantity').html($findSquare);
	else $(this).parent().find('.digit-quantity').html('0');
});

// Клик по картинке
$('.img_click').on('click', function(){
  /*
	var $itemsParent =  $(this).closest('.room-content');
	$itemsParent.find('.img_click').removeClass('img-active');
	$(this).addClass('img-active');
  */
  $(this).toggleClass('img-active');
	Recalc();
});

// Количество комнат пересчет
  $('.apt').on('click', function(){
    $('.apt').removeClass('apt-active');
    $(this).addClass('apt-active');
	$rooms_count = $(this).data('room_count');
	$('.room').addClass('disable');
	for ($i = 1; $i <= $rooms_count; $i++)
		{		
		$('.room-'+$i).removeClass('disable');		
		}
	console.log('Recalculation by: apt click');
	Recalc();
	recalcSquare();
  });
  
// Количество туалетов пересчет
  $('.toilet-select').on('click', function(){
    $('.toilet-select').removeClass('toilet-active');
    $(this).addClass('toilet-active');
	$toilets_count = $(this).data('toilet_count');
	console.log('cnt'+$toilets_count);
	$('.toilet').addClass('disable');
	for ($i = 1; $i <= $toilets_count; $i++)
		{		
		$('.toilet-'+$i).removeClass('disable');		
		}
	console.log('Recalculation by: toilet click');
	Recalc();
	recalcSquare();
  });  
  
// Количество лоджий пересчет
  $('.loggia-select').on('click', function(){
    $('.loggia-select').removeClass('loggia-active');
    $(this).addClass('loggia-active');
	$loggias_count = $(this).data('loggia_count');
	console.log('cnt'+$loggias_count);
	$('.loggia').addClass('disable');
	for ($i = 1; $i <= $loggias_count; $i++)
		{		
		$('.loggia-'+$i).removeClass('disable');		
		}
	console.log('Recalculation by: loggia click');
	Recalc();
	recalcSquare();
  });


// CHANGE SQUARE FUNCTIONS
  
  $('.toilet-square, .kitchen-square, .coridor-square, .room-square, .digit_insert, .walls_height_input, .window_input, .loggia-square').on('change', function(){
	$walls_height = $('.walls_height_input').val();
	recalcSquare();
  });

  function recalcSquare()
  {
    //console.log($('.toilet-square').val());
    var $square_full,
        $square_toilet1 = parseInt($('.toilet1-square').val()),
        $square_toilet2 = parseInt($('.toilet2-square').val()),
        $square_toilet3 = parseInt($('.toilet3-square').val()),
        $square_kitchen = parseInt($('.kitchen-square').val()),
        $square_coridor = parseInt($('.coridor-square').val()),
        $square_room1 = parseInt($('.room1-square').val()),
        $square_room2 = parseInt($('.room2-square').val()),
        $square_room3 = parseInt($('.room3-square').val()),
        $square_room4 = parseInt($('.room4-square').val()),
        $square_room5 = parseInt($('.room5-square').val()),
        $square_room6 = parseInt($('.room6-square').val()),
        $square_room7 = parseInt($('.room7-square').val()),
		$square_loggia1 = parseInt($('.loggia1-square').val()),
		$square_loggia2 = parseInt($('.loggia2-square').val());        
		
	$('.toilet1-square').attr('value', $square_toilet1);
	$('.toilet2-square').attr('value', $square_toilet2);
	$('.toilet3-square').attr('value', $square_toilet3);
	$('.kitchen-square').attr('value', $square_kitchen);
	$('.coridor-square').attr('value', $square_coridor);
	$('.room1-square').attr('value', $square_room1);	
	$('.room2-square').attr('value', $square_room2);
	$('.room3-square').attr('value', $square_room3);
	$('.room4-square').attr('value', $square_room4);	
	$('.room5-square').attr('value', $square_room5);	
	$('.room6-square').attr('value', $square_room6);	
	$('.room7-square').attr('value', $square_room7);
	$('.loggia1-square').attr('value', $square_loggia1);
	$('.loggia2-square').attr('value', $square_loggia2);
	
	
        
// Учет дверных оконных проемов
for ($i = 1; $i <= $rooms_count; $i++)
  {
  var $room = $('.room_'+$i+'_window');
  //console.log($room);
  console.log($room.length);  
  $square = 0;
  $t = 0;
  for ($j = 0; $j<$room.length; $j++)
    {    
    if ($j%2 == 0) $t = $room.eq($j).val();
    else $square = $square + ($t * $room.eq($j).val());
    }
  $room_windows[$i] = $square;
  }
  //console.log($room_windows);
  
  
	$square_full = $square_kitchen + $square_toilet1 + $square_coridor + $square_room1 + $square_loggia1;

	
	//console.log( $square_kitchen +':'+ $square_toilet1 +':'+ $square_coridor +':'+ $square_room1);
	
	if (!$('.room-2').hasClass('disable') && !isNaN($square_room2)) $square_full = $square_full + $square_room2; 
	if (!$('.room-3').hasClass('disable') && !isNaN($square_room3)) $square_full = $square_full + $square_room3; 
	if (!$('.room-4').hasClass('disable') && !isNaN($square_room4)) $square_full = $square_full + $square_room4; 
	if (!$('.room-5').hasClass('disable') && !isNaN($square_room5)) $square_full = $square_full + $square_room5; 
	if (!$('.room-6').hasClass('disable') && !isNaN($square_room6)) $square_full = $square_full + $square_room6; 
	if (!$('.room-7').hasClass('disable') && !isNaN($square_room7)) $square_full = $square_full + $square_room7; 
	
	if (!$('.toilet-2').hasClass('disable') && !isNaN($square_toilet2)) $square_full = $square_full + $square_toilet2;
	if (!$('.toilet-3').hasClass('disable') && !isNaN($square_toilet3)) $square_full = $square_full + $square_toilet3;
	
	if (!$('.loggia-2').hasClass('disable') && !isNaN($square_loggia2)) $square_full = $square_full + $square_loggia2;	
    
	$('.apt-square-full').html($square_full+' кв.м.');
    console.log('Recalculation by: recalcSquare ');
    Recalc();
  }
  
// ADDITIONAL PLUS\MINUS FUNCTIONS

$('.plus').on('click', function(){
	var p = parseInt($(this).parent().find('.digit').html());
	p = p + 1;
	if (p > 9) p = 9;
	$(this).parent().find('.digit').html(p)
	Recalc();
});
$('.minus').on('click', function(){
	var p = parseInt($(this).parent().find('.digit').html());
	p = p - 1;
	if (p < 0) p = 0;
	$(this).parent().find('.digit').html(p)
	Recalc();
});

// MAIN CALCULATION FUNCTIONS

function Recalc()
  {
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	  
// Комнаты АВТО
	var priceRoomFloor 		= [],
		priceRoomRoof 		= [],
		priceRoomWall 		= [],
		squareRoom 			= [],
		priceRoomFloor 		= [],
		priceRoomRoof 		= [],
		priceRoomWall 		= [],
		priceRoomAdditional	= [],
		priceRoomFull 		= [];
		
	for ($i = 1; $i <= $rooms_count; $i++)
		{		
    $tmp = $('.img-room'+$i+'-floor.img-active');    
    priceRoomFloor[$i] = 0;
    for ($j = 0; $j < $tmp.length; $j++) priceRoomFloor[$i] = priceRoomFloor[$i] + $tmp.eq($j).data('price');		
    
    $tmp = $('.img-room'+$i+'-roof.img-active');    
    priceRoomRoof[$i] = 0;
    for ($j = 0; $j < $tmp.length; $j++) priceRoomRoof[$i] = priceRoomRoof[$i] + $tmp.eq($j).data('price');    
    
    $tmp = $('.img-room'+$i+'-wall.img-active');    
    priceRoomWall[$i] = 0;
    for ($j = 0; $j < $tmp.length; $j++) priceRoomWall[$i] = priceRoomWall[$i] + $tmp.eq($j).data('price');

/*
// BEFORE MULTISELECT    
    priceRoomFloor[$i]	= parseInt($('.img-room'+$i+'-floor.img-active').data('price'));
		priceRoomRoof[$i]	= parseInt($('.img-room'+$i+'-roof.img-active').data('price')),
		priceRoomWall[$i]	= parseInt($('.img-room'+$i+'-wall.img-active').data('price')),
*/
		squareRoom[$i]		= parseInt($('.room'+$i+'-square').val());

// ROOMS Additional calculation
		priceRoomAdditional[$i] = 0;
		$.each($('.img-room'+$i+'-additional'),function(index,value)
			{
			//console.log($(this).parent().find('.digit').html());
			var q,
				p = $(this).data('price');			
			q = parseInt($(this).parent().find('.digit-quantity').html());
			
			
			if (isNaN(q)) q = parseInt($(this).parent().find('.digit-quantity').val());
			
			if(isNaN(q)) q = 0;
			if(isNaN(p)) p = 0;
			
			if(q != 0)
				{				
				priceRoomAdditional[$i] = priceRoomAdditional[$i] + (q*p);
				console.log('Additional: '+q+' : '+p+' : '+priceRoomAdditional[$i]);
				}
			})
		if (isNaN(priceRoomAdditional[$i])) priceRoomAdditional[$i] = 0;
		
// ROOMS main calculation
		priceRoomFloor[$i] = priceRoomFloor[$i] * squareRoom[$i];
		if(isNaN(priceRoomFloor[$i])) priceRoomFloor[$i] = 0;
		
		priceRoomRoof[$i]  = priceRoomRoof[$i]  * squareRoom[$i];
		if(isNaN(priceRoomRoof[$i])) priceRoomRoof[$i] = 0;
		
		priceRoomWall[$i]  = parseInt(priceRoomWall[$i]  * ((Math.sqrt(squareRoom[$i]) * $walls_height * 4) - $room_windows[$i]));
		if(isNaN(priceRoomWall[$i])) priceRoomWall[$i] = 0;
		
		priceRoomFull[$i]  = parseInt(priceRoomFloor[$i] + priceRoomWall[$i] + priceRoomRoof[$i] + priceRoomAdditional[$i]);
		if(isNaN(priceRoomFull[$i])) priceRoomFull[$i] = 0;
		
		$('.room'+$i+'-cost').html(priceRoomFull[$i]);
		
		//console.log(priceRoomAdditional[$i]+' '+priceRoomFloor[$i]+' '+priceRoomRoof[$i]+' '+priceRoomWall[$i]+' '+priceRoomFull[$i]);
		}	  

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
// ТУАЛЕТ-ВАННАЯ АВТО
	var priceToiletFloor 		= [],
		priceToiletRoof 		= [],
		priceToiletWall 		= [],
		squareToilet 			= [],
		priceToiletFloor 		= [],
		priceToiletRoof 		= [],
		priceToiletWall 		= [],
		priceToiletAdditional	= [],
		priceToiletFull 		= [];
		
	for ($i = 1; $i <= $toilets_count; $i++)
		{
		$tmp = $('.img-toilet'+$i+'-floor.img-active');    
		priceToiletFloor[$i] = 0;
		for ($j = 0; $j < $tmp.length; $j++) priceToiletFloor[$i] = priceToiletFloor[$i] + $tmp.eq($j).data('price');		
		
		$tmp = $('.img-toilet'+$i+'-roof.img-active');    
		priceToiletRoof[$i] = 0;
		for ($j = 0; $j < $tmp.length; $j++) priceToiletRoof[$i] = priceToiletRoof[$i] + $tmp.eq($j).data('price');    
		
		$tmp = $('.img-toilet'+$i+'-wall.img-active');    
		priceToiletWall[$i] = 0;
		for ($j = 0; $j < $tmp.length; $j++) priceToiletWall[$i] = priceToiletWall[$i] + $tmp.eq($j).data('price');
		/*
		priceToiletFloor[$i]	= parseInt($('.img-toilet'+$i+'-floor.img-active').data('price'));
		priceToiletRoof[$i]	= parseInt($('.img-toilet'+$i+'-roof.img-active').data('price')),
		priceToiletWall[$i]	= parseInt($('.img-toilet'+$i+'-wall.img-active').data('price')),
		*/
		
		squareToilet[$i]		= parseInt($('.toilet'+$i+'-square').val());

// TOILET Additional calculation
		priceToiletAdditional[$i] = 0;
		$.each($('.img-toilet'+$i+'-additional'),function(index,value)
			{
			//console.log($(this).parent().find('.digit').html());
			var q,
				p = $(this).data('price');
			
			q = parseInt($(this).parent().find('.digit-quantity').html());
			if (isNaN(q)) q = parseInt($(this).parent().find('.digit-quantity').val());
			
			if(isNaN(q)) q = 0;
			if(isNaN(p)) p = 0;
			
			if(q != 0)
				{				
				priceToiletAdditional[$i] = priceToiletAdditional[$i] + (q*p);
				console.log('Additional: '+q+' : '+p+' : '+priceToiletAdditional[$i]);
				}
			})
		if (isNaN(priceToiletAdditional[$i])) priceToiletAdditional[$i] = 0;
		
// TOILET main calculation
		priceToiletFloor[$i] = priceToiletFloor[$i] * squareToilet[$i];
		if(isNaN(priceToiletFloor[$i])) priceToiletFloor[$i] = 0;
		
		priceToiletRoof[$i]  = priceToiletRoof[$i]  * squareToilet[$i];
		if(isNaN(priceToiletRoof[$i])) priceToiletRoof[$i] = 0;
		
		priceToiletWall[$i]  = parseInt(priceToiletWall[$i]  * (Math.sqrt(squareToilet[$i])*$walls_height*4));
		if(isNaN(priceToiletWall[$i])) priceToiletWall[$i] = 0;
		
		priceToiletFull[$i]  = parseInt(priceToiletFloor[$i] + priceToiletWall[$i] + priceToiletRoof[$i] + priceToiletAdditional[$i]);
		if(isNaN(priceToiletFull[$i])) priceToiletFull[$i] = 0;
		
		$('.toilet'+$i+'-cost').html(priceToiletFull[$i]);
		
		//console.log(priceToiletAdditional[$i]+' '+priceToiletFloor[$i]+' '+priceToiletRoof[$i]+' '+priceToiletWall[$i]+' '+priceToiletFull[$i]);
		}
		
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
// КОРИДОР АВТО
	var priceCoridorFloor 		= [],
		priceCoridorRoof 		= [],
		priceCoridorWall 		= [],
		squareCoridor 			= [],
		priceCoridorFloor 		= [],
		priceCoridorRoof 		= [],
		priceCoridorWall 		= [],
		priceCoridorAdditional	= [],
		priceCoridorFull 		= [];
		
	for ($i = 1; $i <= $coridors_count; $i++)
		{
		$tmp = $('.img-coridor'+$i+'-floor.img-active');    
		priceCoridorFloor[$i] = 0;
		for ($j = 0; $j < $tmp.length; $j++) priceCoridorFloor[$i] = priceCoridorFloor[$i] + $tmp.eq($j).data('price');		
		
		$tmp = $('.img-coridor'+$i+'-roof.img-active');    
		priceCoridorRoof[$i] = 0;
		for ($j = 0; $j < $tmp.length; $j++) priceCoridorRoof[$i] = priceCoridorRoof[$i] + $tmp.eq($j).data('price');    
		
		$tmp = $('.img-coridor'+$i+'-wall.img-active');    
		priceCoridorWall[$i] = 0;
		for ($j = 0; $j < $tmp.length; $j++) priceCoridorWall[$i] = priceCoridorWall[$i] + $tmp.eq($j).data('price');
		/*	
		priceCoridorFloor[$i]	= parseInt($('.img-coridor'+$i+'-floor.img-active').data('price'));
		priceCoridorRoof[$i]	= parseInt($('.img-coridor'+$i+'-roof.img-active').data('price')),
		priceCoridorWall[$i]	= parseInt($('.img-coridor'+$i+'-wall.img-active').data('price')),
		*/
		squareCoridor[$i]		= parseInt($('.coridor'+$i+'-square').val());

// CORIDOR Additional calculation
		priceCoridorAdditional[$i] = 0;
		$.each($('.img-coridor'+$i+'-additional'),function(index,value)
			{
			//console.log($(this).parent().find('.digit').html());
			var q,
				p = $(this).data('price');
			
			q = parseInt($(this).parent().find('.digit-quantity').html());
			if (isNaN(q)) q = parseInt($(this).parent().find('.digit-quantity').val());
			
			if(isNaN(q)) q = 0;
			if(isNaN(p)) p = 0;
			
			if(q != 0)
				{				
				priceCoridorAdditional[$i] = priceCoridorAdditional[$i] + (q*p);
				console.log('Additional: '+q+' : '+p+' : '+priceCoridorAdditional[$i]);
				}
			})
		if (isNaN(priceCoridorAdditional[$i])) priceCoridorAdditional[$i] = 0;
		
// CORIDOR main calculation
		priceCoridorFloor[$i] = priceCoridorFloor[$i] * squareCoridor[$i];
		if(isNaN(priceCoridorFloor[$i])) priceCoridorFloor[$i] = 0;
		
		priceCoridorRoof[$i]  = priceCoridorRoof[$i]  * squareCoridor[$i];
		if(isNaN(priceCoridorRoof[$i])) priceCoridorRoof[$i] = 0;
		
		priceCoridorWall[$i]  = parseInt(priceCoridorWall[$i]  * (Math.sqrt(squareCoridor[$i])*$walls_height*4));
		if(isNaN(priceCoridorWall[$i])) priceCoridorWall[$i] = 0;
		
		priceCoridorFull[$i]  = parseInt(priceCoridorFloor[$i] + priceCoridorWall[$i] + priceCoridorRoof[$i] + priceCoridorAdditional[$i]);
		if(isNaN(priceCoridorFull[$i])) priceCoridorFull[$i] = 0;
		
		$('.coridor'+$i+'-cost').html(priceCoridorFull[$i]);
		
		//console.log(priceCoridorAdditional[$i]+' '+priceCoridorFloor[$i]+' '+priceCoridorRoof[$i]+' '+priceCoridorWall[$i]+' '+priceCoridorFull[$i]);
		}
		
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				
// КУХНЯ АВТО
	var priceKitchenFloor 		= [],
		priceKitchenRoof 		= [],
		priceKitchenWall 		= [],
		squareKitchen 			= [],
		priceKitchenFloor 		= [],
		priceKitchenRoof 		= [],
		priceKitchenWall 		= [],
		priceKitchenAdditional	= [],
		priceKitchenFull 		= [];
		
	for ($i = 1; $i <= $kitchens_count; $i++)
		{
		$tmp = $('.img-kitchen'+$i+'-floor.img-active');    
		priceKitchenFloor[$i] = 0;
		for ($j = 0; $j < $tmp.length; $j++) priceKitchenFloor[$i] = priceKitchenFloor[$i] + $tmp.eq($j).data('price');		
		
		$tmp = $('.img-kitchen'+$i+'-roof.img-active');    
		priceKitchenRoof[$i] = 0;
		for ($j = 0; $j < $tmp.length; $j++) priceKitchenRoof[$i] = priceKitchenRoof[$i] + $tmp.eq($j).data('price');    
		
		$tmp = $('.img-kitchen'+$i+'-wall.img-active');    
		priceKitchenWall[$i] = 0;
		for ($j = 0; $j < $tmp.length; $j++) priceKitchenWall[$i] = priceKitchenWall[$i] + $tmp.eq($j).data('price');
		/*
		priceKitchenFloor[$i]	= parseInt($('.img-kitchen'+$i+'-floor.img-active').data('price'));
		priceKitchenRoof[$i]	= parseInt($('.img-kitchen'+$i+'-roof.img-active').data('price')),
		priceKitchenWall[$i]	= parseInt($('.img-kitchen'+$i+'-wall.img-active').data('price')),
		*/
		squareKitchen[$i]		= parseInt($('.kitchen'+$i+'-square').val());

// KITCHEN Additional calculation
		priceKitchenAdditional[$i] = 0;
		$.each($('.img-kitchen'+$i+'-additional'),function(index,value)
			{
			//console.log($(this).parent().find('.digit').html());
			var q,
				p = $(this).data('price');
			
			q = parseInt($(this).parent().find('.digit-quantity').html());
			if (isNaN(q)) q = parseInt($(this).parent().find('.digit-quantity').val());
			
			if(isNaN(q)) q = 0;
			if(isNaN(p)) p = 0;
			
			if(q != 0)
				{				
				priceKitchenAdditional[$i] = priceKitchenAdditional[$i] + (q*p);
				console.log('Additional: '+q+' : '+p+' : '+priceKitchenAdditional[$i]);
				}
			})
		if (isNaN(priceKitchenAdditional[$i])) priceKitchenAdditional[$i] = 0;
		
// KITCHEN main calculation
		priceKitchenFloor[$i] = priceKitchenFloor[$i] * squareKitchen[$i];
		if(isNaN(priceKitchenFloor[$i])) priceKitchenFloor[$i] = 0;
		
		priceKitchenRoof[$i]  = priceKitchenRoof[$i]  * squareKitchen[$i];
		if(isNaN(priceKitchenRoof[$i])) priceKitchenRoof[$i] = 0;
		
		priceKitchenWall[$i]  = parseInt(priceKitchenWall[$i]  * (Math.sqrt(squareKitchen[$i])*$walls_height*4));
		if(isNaN(priceKitchenWall[$i])) priceKitchenWall[$i] = 0;
		
		priceKitchenFull[$i]  = parseInt(priceKitchenFloor[$i] + priceKitchenWall[$i] + priceKitchenRoof[$i] + priceKitchenAdditional[$i]);
		if(isNaN(priceKitchenFull[$i])) priceKitchenFull[$i] = 0;
		
		$('.kitchen'+$i+'-cost').html(priceKitchenFull[$i]);
		
		//console.log(priceKitchenAdditional[$i]+' '+priceKitchenFloor[$i]+' '+priceKitchenRoof[$i]+' '+priceKitchenWall[$i]+' '+priceKitchenFull[$i]);
		}
		
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				
// ЛОДЖИЯ АВТО
	var priceLoggiaFloor 		= [],
		priceLoggiaRoof 		= [],
		priceLoggiaWall 		= [],
		squareLoggia 			= [],
		priceLoggiaFloor 		= [],
		priceLoggiaRoof 		= [],
		priceLoggiaWall 		= [],
		priceLoggiaAdditional	= [],
		priceLoggiaFull 		= [];
		
	for ($i = 1; $i <= $loggias_count; $i++)
		{
		$tmp = $('.img-loggia'+$i+'-floor.img-active');    
		priceLoggiaFloor[$i] = 0;
		for ($j = 0; $j < $tmp.length; $j++) priceLoggiaFloor[$i] = priceLoggiaFloor[$i] + $tmp.eq($j).data('price');		
		
		$tmp = $('.img-loggia'+$i+'-roof.img-active');    
		priceLoggiaRoof[$i] = 0;
		for ($j = 0; $j < $tmp.length; $j++) priceLoggiaRoof[$i] = priceLoggiaRoof[$i] + $tmp.eq($j).data('price');    
		
		$tmp = $('.img-loggia'+$i+'-wall.img-active');    
		priceLoggiaWall[$i] = 0;
		for ($j = 0; $j < $tmp.length; $j++) priceLoggiaWall[$i] = priceLoggiaWall[$i] + $tmp.eq($j).data('price');
		/*
		priceLoggiaFloor[$i]	= parseInt($('.img-loggia'+$i+'-floor.img-active').data('price'));
		priceLoggiaRoof[$i]	= parseInt($('.img-loggia'+$i+'-roof.img-active').data('price')),
		priceLoggiaWall[$i]	= parseInt($('.img-loggia'+$i+'-wall.img-active').data('price')),
		*/
		squareLoggia[$i]		= parseInt($('.loggia'+$i+'-square').val());

// LOGGIA Additional calculation
		priceLoggiaAdditional[$i] = 0;
		$.each($('.img-loggia'+$i+'-additional'),function(index,value)
			{
			//console.log($(this).parent().find('.digit').html());
			var q,
				p = $(this).data('price');
			
			q = parseInt($(this).parent().find('.digit-quantity').html());
			if (isNaN(q)) q = parseInt($(this).parent().find('.digit-quantity').val());
			
			if(isNaN(q)) q = 0;
			if(isNaN(p)) p = 0;
			
			if(q != 0)
				{				
				priceLoggiaAdditional[$i] = priceLoggiaAdditional[$i] + (q*p);
				console.log('Additional: '+q+' : '+p+' : '+priceLoggiaAdditional[$i]);
				}
			})
		if (isNaN(priceLoggiaAdditional[$i])) priceLoggiaAdditional[$i] = 0;
		
// LOGGIA main calculation
		priceLoggiaFloor[$i] = priceLoggiaFloor[$i] * squareLoggia[$i];
		if(isNaN(priceLoggiaFloor[$i])) priceLoggiaFloor[$i] = 0;
		
		priceLoggiaRoof[$i]  = priceLoggiaRoof[$i]  * squareLoggia[$i];
		if(isNaN(priceLoggiaRoof[$i])) priceLoggiaRoof[$i] = 0;
		
		priceLoggiaWall[$i]  = parseInt(priceLoggiaWall[$i]  * (Math.sqrt(squareLoggia[$i])*$walls_height*4));
		if(isNaN(priceLoggiaWall[$i])) priceLoggiaWall[$i] = 0;
		
		priceLoggiaFull[$i]  = parseInt(priceLoggiaFloor[$i] + priceLoggiaWall[$i] + priceLoggiaRoof[$i] + priceLoggiaAdditional[$i]);
		if(isNaN(priceLoggiaFull[$i])) priceLoggiaFull[$i] = 0;
		
		$('.loggia'+$i+'-cost').html(priceLoggiaFull[$i]);
		
		//console.log(priceLoggiaAdditional[$i]+' '+priceLoggiaFloor[$i]+' '+priceLoggiaRoof[$i]+' '+priceLoggiaWall[$i]+' '+priceLoggiaFull[$i]);
		}
		
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
//// Итог

  var $priceFull = 0;
  
  for($i = 1; $i <= (priceRoomFull.length-1); $i++)
	{	
	$priceFull = $priceFull + priceRoomFull[$i];
	}
	
  for($i = 1; $i <= (priceToiletFull.length-1); $i++)
	{	
	$priceFull = $priceFull + priceToiletFull[$i];
	}	
	
  for($i = 1; $i <= (priceCoridorFull.length-1); $i++)
	{	
	$priceFull = $priceFull + priceCoridorFull[$i];
	}
	
  for($i = 1; $i <= (priceKitchenFull.length-1); $i++)
	{	
	$priceFull = $priceFull + priceKitchenFull[$i];
	}	
	
  for($i = 1; $i <= (priceLoggiaFull.length-1); $i++)
	{	
	$priceFull = $priceFull + priceLoggiaFull[$i];
	}
	
  $('.price-full').html($priceFull + ' &#8381;');
  }
