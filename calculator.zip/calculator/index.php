<?php
include('include/sql_connect.php');
$rooms_count = 7;
$toilets_count = 3;
$coridors_count = 1;
$kitchens_count = 1;
$loggias_count = 2;
?>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link rel="stylesheet" type="text/css" href="/calculator/css/accordeon.css" />
		<link rel="stylesheet" type="text/css" href="/calculator/css/style.css" />
		<script src="/calculator/js/jquery-3.3.1.min.js"></script>
	</head>
	<body>
  <p style="padding: 20px; text-align: center; color: gray; font-style: italic;">*Расчеты произведенные данным калькулятором не являеюся публичной офертой и носят ознакомительный характер. Для точного расчета заполните заявку на расчет или позвоните по номеру указанному в разделе <a href="http://palladastroy.ru/contacts/">Контакты</a></a></p>
		<div class="content">
			<h1>Онлайн калькулятор</h1>
			<div class="apt-block">
				<div class="walls_height">Высота стен</br><input pattern="\d+(\.\d{2})?" type="text" value="2.8" class="walls_height_input">метра</div>
				<div class="apt-square">Площадь квартиры<br><div class="apt-square-full">0</div></div>
			</div>
<!-- ВЫБОР КОЛИЧЕСТВА КОМНАТ -->
			<div class="apt-block">
				<?php
				for($i = 1; $i <= $rooms_count; $i++)
					{
					if ($i == $rooms_count) echo '<div data-room_count="'.$i.'" class="apt apt_'.$i.' apt-active">'.$i.' комнатная <br> квартира</div>';
					else echo '<div data-room_count="'.$i.'" class="apt apt_'.$i.'">'.$i.' комнатная <br> квартира</div>';
					}
				?>
			</div>
<!-- ВЫБОР КОЛИЧЕСТВА ТУАЛЕТОВ -->
			<div class="toilet-block">
				<?php
				for($i = 1; $i <= $toilets_count; $i++)
					{
					if ($i == 1) echo '<div data-toilet_count="'.$i.'" class="toilet-select toilet_'.$i.' toilet-active">Количество туалетов: '.$i.'</div>';
					else echo '<div data-toilet_count="'.$i.'" class="toilet-select">Количество туалетов: '.$i.'</div>';
					}
				?>
			</div>
<!-- ВЫБОР КОЛИЧЕСТВА ЛОДЖИЙ -->
			<div class="loggia-block">
				<?php
				for($i = 1; $i <= $loggias_count; $i++)
					{
					if ($i == 1) echo '<div data-loggia_count="'.$i.'" class="loggia-select loggia_'.$i.' loggia-active">Количество лоджий: '.$i.'</div>';
					else echo '<div data-loggia_count="'.$i.'" class="loggia-select">Количество лоджий: '.$i.'</div>';
					}
				?>
			</div>
<!-- ------------------------------------------- -->
			<div class="sub-content">
				<p style="display: inline-block; vertical-align: center;">Посмотрите самые популярные варианты ремонта и внесите изменения, там где хочется</p>
				<div class="rooms-block">					
<?php

$roomsFloor = getRooms('Комната', 'Пол');
$roomsRoof 	= getRooms('Комната', 'Потолок');
$roomsWall 	= getRooms('Комната', 'Стены');
$roomsAdd 	= getRooms('Комната', 'Дополнительно');

$toiletsFloor 	= getRooms('Ванная-туалет', 'Пол');
$toiletsRoof 	= getRooms('Ванная-туалет', 'Потолок');
$toiletsWall 	= getRooms('Ванная-туалет', 'Стены');
$toiletsAdd 	= getRooms('Ванная-туалет', 'Дополнительно');

$сoridorsFloor 	= getRooms('Коридор', 'Пол');
$сoridorsRoof 	= getRooms('Коридор', 'Потолок');
$сoridorsWall 	= getRooms('Коридор', 'Стены');
$сoridorsAdd 	= getRooms('Коридор', 'Дополнительно');

$kitchensFloor 	= getRooms('Кухня', 'Пол');
$kitchensRoof 	= getRooms('Кухня', 'Потолок');
$kitchensWall 	= getRooms('Кухня', 'Стены');
$kitchensAdd 	= getRooms('Кухня', 'Дополнительно');

$loggiasFloor 	= getRooms('Лоджия', 'Пол');
$loggiasRoof 	= getRooms('Лоджия', 'Потолок');
$loggiasWall 	= getRooms('Лоджия', 'Стены');
$loggiasAdd 	= getRooms('Лоджия', 'Дополнительно');

//var_dump($kitchensRoof);die;

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// КОМНАТЫ
for ($i=1; $i <= $rooms_count ; $i++)
{
// Блок комнаты старт
echo '<div class="eSquare1 room room-'.$i.'">';
// Главная строка помещения
	echo '<div class="room-top-string">';
		echo '<div class="room-top room-name">Комната '.$i.'</div>';
		echo '<div class="room-top ">Уточните площадь: <input type="text" name="room'.$i.'-square" value="15" class="room-square eSquare2 room'.$i.'-square">кв.м.</div>';
		echo '<div class="room-top ">Стоимость ремонта: <strong><div class="room-top room'.$i.'-cost">0</div>&#8381;</strong></div>';
	echo '</div>';


// Пол помещения
	echo '<div class="accordion">';
		echo '<section class="accordion_item">';
			echo '<div class="room-sub">';
				echo '<div class="room-top room-name title_block">Комната '.$i.' - '.$roomsFloor[0]['type'].'</div>';
				echo '<div class="info">';
					echo '<div class="room-top room'.$i.'-floor-text"></div>';
						echo '<div class="room-content">';							
							foreach($roomsFloor as $k => $v)
								{
								echo '<div class="item">';
									echo '<img data-price="'.$v['price'].'" class="img_click img-room'.$i.'-floor" alt="'.$v['service'].'" src="/calculator/images/'.$v['image'].'"/>';
									echo '<p><b>'.$v['service'].'</b></p>';								
									echo '<i>'.$v['description'].'</i>';									
								echo '</div>';
								}							
						echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</section>';
	echo '</div>';
	
// Потолок помещения
	echo '<div class="accordion">';
		echo '<section class="accordion_item">';
			echo '<div class="room-sub">';
				echo '<div class="room-top room-name title_block">Комната '.$i.' - '.$roomsRoof[0]['type'].'</div>';
				echo '<div class="info">';
					echo '<div class="room-top room'.$i.'-roof-text"></div>';
						echo '<div class="room-content">';							
							foreach($roomsRoof as $k => $v)
								{
								echo '<div class="item">';
									echo '<img data-price="'.$v['price'].'" class="img_click img-room'.$i.'-roof" alt="'.$v['service'].'" src="/calculator/images/'.$v['image'].'"/>';
									echo '<p><b>'.$v['service'].'</b></p>';								
									echo '<i>'.$v['description'].'</i>';									
								echo '</div>';
								}							
						echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</section>';
	echo '</div>';
	
// Cтены помещения
	echo '<div class="accordion">';
		echo '<section class="accordion_item">';
			echo '<div class="room-sub">';
				echo '<div class="room-top room-name title_block">Комната '.$i.' - '.$roomsWall[0]['type'].'</div>';
				echo '<div class="info">';
					echo '<div class="room-top room'.$i.'-wall-text"></div>';
						echo '<div class="room-content">';
            ?>
              <p align="center">Оконные и дверные проемы</p>
              <div class="window_block">
                <table><tr><td colspan="2">Окно 1</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input room_<?php echo $i; ?>_window window_width1">
                  Высота(м): <input type="text" value="0" class="window_input room_<?php echo $i; ?>_window window_height1">
                </td><td><img style="float: right;" src="/calculator/images/window.png" /></td></tr></table>
                <table><tr><td colspan="2">Окно 2</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input room_<?php echo $i; ?>_window window_width2">
                  Высота(м): <input type="text" value="0" class="window_input room_<?php echo $i; ?>_window  window_height2">
                </td><td><img style="float: right;" src="/calculator/images/window.png" /></td></tr></table>
                <table><tr><td colspan="2">Окно 3</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input room_<?php echo $i; ?>_window  window_width3">
                  Высота(м): <input type="text" value="0" class="window_input room_<?php echo $i; ?>_window  window_height3">
                </td><td><img style="float: right;" src="/calculator/images/window.png" /></td></tr></table>
                <table><tr><td colspan="2">Дверь 1</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input room_<?php echo $i; ?>_window  door_width1">
                  Высота(м): <input type="text" value="0" class="window_input room_<?php echo $i; ?>_window  door_height1">
                </td><td><img style="float: right;" src="/calculator/images/door.png" /></td></tr></table>
                <table><tr><td colspan="2">Дверь 2</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input room_<?php echo $i; ?>_window  door_width2">
                  Высота(м): <input type="text" value="0" class="window_input room_<?php echo $i; ?>_window  door_height2">
                </td><td><img style="float: right;" src="/calculator/images/door.png" /></td></tr></table>
                <table><tr><td colspan="2">Дверь 3</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input room_<?php echo $i; ?>_window  door_width3">
                  Высота(м): <input type="text" value="0" class="window_input room_<?php echo $i; ?>_window  door_height3">
                </td><td><img style="float: right;" src="/calculator/images/door.png" /></td></tr></table>
                
              </div>
              <hr>
            <?php
							foreach($roomsWall as $k => $v)
								{
								echo '<div class="item">';
									echo '<img data-price="'.$v['price'].'" class="img_click img-room'.$i.'-wall" alt="'.$v['service'].'" src="/calculator/images/'.$v['image'].'"/>';
									echo '<p><b>'.$v['service'].'</b></p>';								
									echo '<i>'.$v['description'].'</i>';									
								echo '</div>';
								}							
						echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</section>';
	echo '</div>';
	
// Дополнительно помещения
	echo '<div class="accordion">';
		echo '<section class="accordion_item">';
			echo '<div class="room-sub">';
				echo '<div class="room-top room-name title_block">Комната '.$i.' - '.$roomsAdd[0]['type'].'</div>';
				echo '<div class="info">';
					echo '<div class="room-top room'.$i.'-wall-text"></div>';
						echo '<div class="room-content">';							
							foreach($roomsAdd as $k => $v)
								{
								// Показываем подтип для дополнительного
								if($k < 1){
									echo '<div class="subTitle">'.$v['sub_type'].'</div>';
									$tmp = $v['sub_type'];}
								if ($tmp != $v['sub_type']){
									$tmp = $v['sub_type'];
									echo '<div class="subTitle">'.$v['sub_type'].'</div>';}
									
								echo '<div class="item">';
									//echo '<img data-price="'.$v['price'].'" class="img-room'.$i.'-wall" alt="'.$v['service'].'" src="/calculator/images/'.$v['image'].'"/>';
									if ($v['control_id'] == 1) echo '<div class="img-add"><img data-price="'.$v['price'].'" class="img-room'.$i.'-additional" alt="" src="/calculator/images/'.$v['image'].'"/><div class="img-add-but"><div class="minus">-</div><div class="digit digit-quantity">0</div><div class="plus">+</div></div></div>';
									if ($v['control_id'] == 2) echo '<div class="img-add"><img data-price="'.$v['price'].'" class="img-room'.$i.'-additional" alt="" src="/calculator/images/'.$v['image'].'"/><div class="img-add-but"><input type="text" placeholder="'.$v['dimension'].'" class="digit_insert digit-quantity"></div></div>';									
									if ($v['control_id'] == 3) echo '<div class="img-add"><img data-price="'.$v['price'].'" class="img_click from-square img-room'.$i.'-additional" alt="" src="/calculator/images/'.$v['image'].'"/><div style="display: none;" class="digit-quantity">0</div></div>';
									echo '<p><b>'.$v['service'].'</b></p>';								
									echo '<i>'.$v['description'].'</i>';									
								echo '</div>';
								}							
						echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</section>';
	echo '</div>';


// Блок комнаты конец
echo '</div>';
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// ТУАЛЕТЫ
for ($i=1; $i <= $toilets_count ; $i++)
{
// Блок Туалет-ванная старт
echo '<div class="eSquare1 toilet toilet-'.$i.'">';
// Главная строка помещения
	echo '<div class="top-string">';
		echo '<div class="room-top room-name">Туалет-ванная '.$i.'</div>';
		echo '<div class="room-top ">Уточните площадь: <input type="text" value="10" class="eSquare2 toilet-square toilet'.$i.'-square">кв.м.</div>';
		echo '<div class="room-top ">Стоимость ремонта: <strong><div class="room-top toilet'.$i.'-cost">0</div>&#8381;</strong></div>';
	echo '</div>';


// Пол помещения
	echo '<div class="accordion">';
		echo '<section class="accordion_item">';
			echo '<div class="room-sub">';
				echo '<div class="room-top room-name title_block">Туалет-ванная '.$i.' - '.$toiletsFloor[0]['type'].'</div>';
				echo '<div class="info">';
					echo '<div class="room-top room'.$i.'-floor-text"></div>';
						echo '<div class="room-content">';							
							foreach($toiletsFloor as $k => $v)
								{
								echo '<div class="item">';
									echo '<img data-price="'.$v['price'].'" class="img_click img-toilet'.$i.'-floor" alt="'.$v['service'].'" src="/calculator/images/'.$v['image'].'"/>';
									echo '<p><b>'.$v['service'].'</b></p>';								
									echo '<i>'.$v['description'].'</i>';									
								echo '</div>';
								}							
						echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</section>';
	echo '</div>';
	
// Потолок помещения
	echo '<div class="accordion">';
		echo '<section class="accordion_item">';
			echo '<div class="room-sub">';
				echo '<div class="room-top room-name title_block">Туалет-ванная '.$i.' - '.$toiletsRoof[0]['type'].'</div>';
				echo '<div class="info">';
					echo '<div class="room-top room'.$i.'-roof-text"></div>';
						echo '<div class="room-content">';							
							foreach($toiletsRoof as $k => $v)
								{
								echo '<div class="item">';
									echo '<img data-price="'.$v['price'].'" class="img_click img-toilet'.$i.'-roof" alt="'.$v['service'].'" src="/calculator/images/'.$v['image'].'"/>';
									echo '<p><b>'.$v['service'].'</b></p>';								
									echo '<i>'.$v['description'].'</i>';									
								echo '</div>';
								}							
						echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</section>';
	echo '</div>';
	
// Cтены помещения
	echo '<div class="accordion">';
		echo '<section class="accordion_item">';
			echo '<div class="room-sub">';
				echo '<div class="room-top room-name title_block">Туалет-ванная '.$i.' - '.$toiletsWall[0]['type'].'</div>';
				echo '<div class="info">';
					echo '<div class="room-top room'.$i.'-wall-text"></div>';
						echo '<div class="room-content">';
            ?>
              <p align="center">Оконные и дверные проемы</p>
              <div class="window_block">
                <table><tr><td colspan="2">Окно 1</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input toilet_<?php echo $i; ?>_window window_width1">
                  Высота(м): <input type="text" value="0" class="window_input toilet_<?php echo $i; ?>_window window_height1">
                </td><td><img style="float: right;" src="/calculator/images/window.png" /></td></tr></table>
                <table><tr><td colspan="2">Окно 2</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input toilet_<?php echo $i; ?>_window window_width2">
                  Высота(м): <input type="text" value="0" class="window_input toilet_<?php echo $i; ?>_window  window_height2">
                </td><td><img style="float: right;" src="/calculator/images/window.png" /></td></tr></table>
                <table><tr><td colspan="2">Окно 3</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input toilet_<?php echo $i; ?>_window  window_width3">
                  Высота(м): <input type="text" value="0" class="window_input toilet_<?php echo $i; ?>_window  window_height3">
                </td><td><img style="float: right;" src="/calculator/images/window.png" /></td></tr></table>
                <table><tr><td colspan="2">Дверь 1</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input toilet_<?php echo $i; ?>_window  door_width1">
                  Высота(м): <input type="text" value="0" class="window_input toilet_<?php echo $i; ?>_window  door_height1">
                </td><td><img style="float: right;" src="/calculator/images/door.png" /></td></tr></table>
                <table><tr><td colspan="2">Дверь 2</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input toilet_<?php echo $i; ?>_window  door_width2">
                  Высота(м): <input type="text" value="0" class="window_input toilet_<?php echo $i; ?>_window  door_height2">
                </td><td><img style="float: right;" src="/calculator/images/door.png" /></td></tr></table>
                <table><tr><td colspan="2">Дверь 3</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input toilet_<?php echo $i; ?>_window  door_width3">
                  Высота(м): <input type="text" value="0" class="window_input toilet_<?php echo $i; ?>_window  door_height3">
                </td><td><img style="float: right;" src="/calculator/images/door.png" /></td></tr></table>
                
              </div>
              <hr>
            <?php						
							foreach($toiletsWall as $k => $v)
								{
								echo '<div class="item">';
									echo '<img data-price="'.$v['price'].'" class="img_click img-toilet'.$i.'-wall" alt="'.$v['service'].'" src="/calculator/images/'.$v['image'].'"/>';
									echo '<p><b>'.$v['service'].'</b></p>';								
									echo '<i>'.$v['description'].'</i>';									
								echo '</div>';
								}							
						echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</section>';
	echo '</div>';
	
// Дополнительно помещения
	echo '<div class="accordion">';
		echo '<section class="accordion_item">';
			echo '<div class="room-sub">';
				echo '<div class="room-top room-name title_block">Туалет-ванная '.$i.' - '.$toiletsAdd[0]['type'].'</div>';
				echo '<div class="info">';
					echo '<div class="room-top room'.$i.'-wall-text"></div>';
						echo '<div class="room-content">';							
							foreach($toiletsAdd as $k => $v)
								{
								// Показываем подтип для дополнительного
								if($k < 1){
									echo '<div class="subTitle">'.$v['sub_type'].'</div>';
									$tmp = $v['sub_type'];}
								if ($tmp != $v['sub_type']){
									$tmp = $v['sub_type'];
									echo '<div class="subTitle">'.$v['sub_type'].'</div>';}
									
								echo '<div class="item">';								
									//echo '<img data-price="'.$v['price'].'" class="img-room'.$i.'-wall" alt="'.$v['service'].'" src="/calculator/images/'.$v['image'].'"/>';
									if ($v['control_id'] == 1) echo '<div class="img-add"><img data-price="'.$v['price'].'" class="img-toilet'.$i.'-additional" alt="" src="/calculator/images/'.$v['image'].'"/><div class="img-add-but"><div class="minus">-</div><div class="digit digit-quantity">0</div><div class="plus">+</div></div></div>';
									if ($v['control_id'] == 2) echo '<div class="img-add"><img data-price="'.$v['price'].'" class="img-toilet'.$i.'-additional" alt="" src="/calculator/images/'.$v['image'].'"/><div class="img-add-but"><input type="text" placeholder="'.$v['dimension'].'" class="digit_insert digit-quantity"></div></div>';
									if ($v['control_id'] == 3) echo '<div class="img-add"><img data-price="'.$v['price'].'" class="img_click from-square img-room'.$i.'-additional" alt="" src="/calculator/images/'.$v['image'].'"/><div style="display: none;" class="digit-quantity">0</div></div>';
									echo '<p><b>'.$v['service'].'</b></p>';								
									echo '<i>'.$v['description'].'</i>';									
								echo '</div>';
								}							
						echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</section>';
	echo '</div>';


// Блок комнаты конец
echo '</div>';
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// КОРИДОР
for ($i=1; $i <= $coridors_count ; $i++)
{
// Блок Коридор старт
echo '<div class="eSquare1 coridor coridor-'.$i.'">';
// Главная строка помещения
	echo '<div class="top-string">';
		echo '<div class="room-top room-name">Коридор '.$i.'</div>';
		echo '<div class="room-top ">Уточните площадь: <input type="text" value="10" class="eSquare2 coridor-square coridor'.$i.'-square">кв.м.</div>';
		echo '<div class="room-top ">Стоимость ремонта: <strong><div class="room-top coridor'.$i.'-cost">0</div>&#8381;</strong></div>';
	echo '</div>';


// Пол помещения
	echo '<div class="accordion">';
		echo '<section class="accordion_item">';
			echo '<div class="room-sub">';
				echo '<div class="room-top room-name title_block">Коридор '.$i.' - '.$сoridorsFloor[0]['type'].'</div>';
				echo '<div class="info">';
					echo '<div class="room-top room'.$i.'-floor-text"></div>';
						echo '<div class="room-content">';							
							foreach($сoridorsFloor as $k => $v)
								{
								echo '<div class="item">';
									echo '<img data-price="'.$v['price'].'" class="img_click img-coridor'.$i.'-floor" alt="'.$v['service'].'" src="/calculator/images/'.$v['image'].'"/>';
									echo '<p><b>'.$v['service'].'</b></p>';								
									echo '<i>'.$v['description'].'</i>';									
								echo '</div>';
								}							
						echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</section>';
	echo '</div>';
	
// Потолок помещения
	echo '<div class="accordion">';
		echo '<section class="accordion_item">';
			echo '<div class="room-sub">';
				echo '<div class="room-top room-name title_block">Коридор '.$i.' - '.$сoridorsRoof[0]['type'].'</div>';
				echo '<div class="info">';
					echo '<div class="room-top room'.$i.'-roof-text"></div>';
						echo '<div class="room-content">';							
							foreach($сoridorsRoof as $k => $v)
								{
								echo '<div class="item">';
									echo '<img data-price="'.$v['price'].'" class="img_click img-coridor'.$i.'-roof" alt="'.$v['service'].'" src="/calculator/images/'.$v['image'].'"/>';
									echo '<p><b>'.$v['service'].'</b></p>';								
									echo '<i>'.$v['description'].'</i>';									
								echo '</div>';
								}							
						echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</section>';
	echo '</div>';
	
// Cтены помещения
	echo '<div class="accordion">';
		echo '<section class="accordion_item">';
			echo '<div class="room-sub">';
				echo '<div class="room-top room-name title_block">Коридор '.$i.' - '.$сoridorsWall[0]['type'].'</div>';
				echo '<div class="info">';
					echo '<div class="room-top room'.$i.'-wall-text"></div>';
						echo '<div class="room-content">';				
            ?>
              <p align="center">Оконные и дверные проемы</p>
              <div class="window_block">
                <table><tr><td colspan="2">Окно 1</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input coridor_<?php echo $i; ?>_window window_width1">
                  Высота(м): <input type="text" value="0" class="window_input coridor_<?php echo $i; ?>_window window_height1">
                </td><td><img style="float: right;" src="/calculator/images/window.png" /></td></tr></table>
                <table><tr><td colspan="2">Окно 2</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input coridor_<?php echo $i; ?>_window window_width2">
                  Высота(м): <input type="text" value="0" class="window_input coridor_<?php echo $i; ?>_window  window_height2">
                </td><td><img style="float: right;" src="/calculator/images/window.png" /></td></tr></table>
                <table><tr><td colspan="2">Окно 3</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input coridor_<?php echo $i; ?>_window  window_width3">
                  Высота(м): <input type="text" value="0" class="window_input coridor_<?php echo $i; ?>_window  window_height3">
                </td><td><img style="float: right;" src="/calculator/images/window.png" /></td></tr></table>
                <table><tr><td colspan="2">Дверь 1</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input coridor_<?php echo $i; ?>_window  door_width1">
                  Высота(м): <input type="text" value="0" class="window_input coridor_<?php echo $i; ?>_window  door_height1">
                </td><td><img style="float: right;" src="/calculator/images/door.png" /></td></tr></table>
                <table><tr><td colspan="2">Дверь 2</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input coridor_<?php echo $i; ?>_window  door_width2">
                  Высота(м): <input type="text" value="0" class="window_input coridor_<?php echo $i; ?>_window  door_height2">
                </td><td><img style="float: right;" src="/calculator/images/door.png" /></td></tr></table>
                <table><tr><td colspan="2">Дверь 3</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input coridor_<?php echo $i; ?>_window  door_width3">
                  Высота(м): <input type="text" value="0" class="window_input coridor_<?php echo $i; ?>_window  door_height3">
                </td><td><img style="float: right;" src="/calculator/images/door.png" /></td></tr></table>
                
              </div>
              <hr>
            <?php						
							foreach($сoridorsWall as $k => $v)
								{
								echo '<div class="item">';
									echo '<img data-price="'.$v['price'].'" class="img_click img-coridor'.$i.'-wall" alt="'.$v['service'].'" src="/calculator/images/'.$v['image'].'"/>';
									echo '<p><b>'.$v['service'].'</b></p>';								
									echo '<i>'.$v['description'].'</i>';									
								echo '</div>';
								}							
						echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</section>';
	echo '</div>';
	
// Дополнительно помещения
	echo '<div class="accordion">';
		echo '<section class="accordion_item">';
			echo '<div class="room-sub">';
				echo '<div class="room-top room-name title_block">Коридор '.$i.' - '.$сoridorsAdd[0]['type'].'</div>';
				echo '<div class="info">';
					echo '<div class="room-top room'.$i.'-wall-text"></div>';
						echo '<div class="room-content">';							
							foreach($сoridorsAdd as $k => $v)
								{
								// Показываем подтип для дополнительного
								if($k < 1){
									echo '<div class="subTitle">'.$v['sub_type'].'</div>';
									$tmp = $v['sub_type'];}
								if ($tmp != $v['sub_type']){
									$tmp = $v['sub_type'];
									echo '<div class="subTitle">'.$v['sub_type'].'</div>';}
									
								echo '<div class="item">';
									//echo '<img data-price="'.$v['price'].'" class="img-room'.$i.'-wall" alt="'.$v['service'].'" src="/calculator/images/'.$v['image'].'"/>';
									if ($v['control_id'] == 1) echo '<div class="img-add"><img data-price="'.$v['price'].'" class="img-coridor'.$i.'-additional" alt="" src="/calculator/images/'.$v['image'].'"/><div class="img-add-but"><div class="minus">-</div><div class="digit digit-quantity">0</div><div class="plus">+</div></div></div>';
									if ($v['control_id'] == 2) echo '<div class="img-add"><img data-price="'.$v['price'].'" class="img-coridor'.$i.'-additional" alt="" src="/calculator/images/'.$v['image'].'"/><div class="img-add-but"><input type="text" placeholder="'.$v['dimension'].'" class="digit_insert digit-quantity"></div></div>';
									if ($v['control_id'] == 3) echo '<div class="img-add"><img data-price="'.$v['price'].'" class="img_click from-square img-room'.$i.'-additional" alt="" src="/calculator/images/'.$v['image'].'"/><div style="display: none;" class="digit-quantity">0</div></div>';
									echo '<p><b>'.$v['service'].'</b></p>';								
									echo '<i>'.$v['description'].'</i>';									
								echo '</div>';
								}							
						echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</section>';
	echo '</div>';


// Блок Коридор конец
echo '</div>';
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// КУХНЯ
for ($i=1; $i <= $kitchens_count ; $i++)
{
// Блок Кухня старт
echo '<div class="eSquare1 kitchen kitchen-'.$i.'">';
// Главная строка помещения
	echo '<div class="top-string">';
		echo '<div class="room-top room-name">Кухня '.$i.'</div>';
		echo '<div class="room-top ">Уточните площадь: <input type="text" value="10" class="eSquare2 kitchen-square kitchen'.$i.'-square">кв.м.</div>';
		echo '<div class="room-top ">Стоимость ремонта: <strong><div class="room-top kitchen'.$i.'-cost">0</div>&#8381;</strong></div>';
	echo '</div>';


// Пол помещения
	echo '<div class="accordion">';
		echo '<section class="accordion_item">';
			echo '<div class="room-sub">';
				echo '<div class="room-top room-name title_block">Кухня '.$i.' - '.$kitchensFloor[0]['type'].'</div>';
				echo '<div class="info">';
					echo '<div class="room-top room'.$i.'-floor-text"></div>';
						echo '<div class="room-content">';							
							foreach($kitchensFloor as $k => $v)
								{
								echo '<div class="item">';
									echo '<img data-price="'.$v['price'].'" class="img_click img-kitchen'.$i.'-floor" alt="'.$v['service'].'" src="/calculator/images/'.$v['image'].'"/>';
									echo '<p><b>'.$v['service'].'</b></p>';								
									echo '<i>'.$v['description'].'</i>';									
								echo '</div>';
								}							
						echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</section>';
	echo '</div>';
	
// Потолок помещения
	echo '<div class="accordion">';
		echo '<section class="accordion_item">';
			echo '<div class="room-sub">';
				echo '<div class="room-top room-name title_block">Кухня '.$i.' - '.$kitchensRoof[0]['type'].'</div>';
				echo '<div class="info">';
					echo '<div class="room-top room'.$i.'-roof-text"></div>';
						echo '<div class="room-content">';							
							foreach($kitchensRoof as $k => $v)
								{
								echo '<div class="item">';
									echo '<img data-price="'.$v['price'].'" class="img_click img-kitchen'.$i.'-roof" alt="'.$v['service'].'" src="/calculator/images/'.$v['image'].'"/>';
									echo '<p><b>'.$v['service'].'</b></p>';								
									echo '<i>'.$v['description'].'</i>';									
								echo '</div>';
								}							
						echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</section>';
	echo '</div>';
	
// Cтены помещения
	echo '<div class="accordion">';
		echo '<section class="accordion_item">';
			echo '<div class="room-sub">';
				echo '<div class="room-top room-name title_block">Кухня '.$i.' - '.$kitchensWall[0]['type'].'</div>';
				echo '<div class="info">';
					echo '<div class="room-top room'.$i.'-wall-text"></div>';
						echo '<div class="room-content">';		
            ?>
              <p align="center">Оконные и дверные проемы</p>
              <div class="window_block">
                <table><tr><td colspan="2">Окно 1</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input kitchen_<?php echo $i; ?>_window window_width1">
                  Высота(м): <input type="text" value="0" class="window_input kitchen_<?php echo $i; ?>_window window_height1">
                </td><td><img style="float: right;" src="/calculator/images/window.png" /></td></tr></table>
                <table><tr><td colspan="2">Окно 2</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input kitchen_<?php echo $i; ?>_window window_width2">
                  Высота(м): <input type="text" value="0" class="window_input kitchen_<?php echo $i; ?>_window  window_height2">
                </td><td><img style="float: right;" src="/calculator/images/window.png" /></td></tr></table>
                <table><tr><td colspan="2">Окно 3</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input kitchen_<?php echo $i; ?>_window  window_width3">
                  Высота(м): <input type="text" value="0" class="window_input kitchen_<?php echo $i; ?>_window  window_height3">
                </td><td><img style="float: right;" src="/calculator/images/window.png" /></td></tr></table>
                <table><tr><td colspan="2">Дверь 1</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input kitchen_<?php echo $i; ?>_window  door_width1">
                  Высота(м): <input type="text" value="0" class="window_input kitchen_<?php echo $i; ?>_window  door_height1">
                </td><td><img style="float: right;" src="/calculator/images/door.png" /></td></tr></table>
                <table><tr><td colspan="2">Дверь 2</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input kitchen_<?php echo $i; ?>_window  door_width2">
                  Высота(м): <input type="text" value="0" class="window_input kitchen_<?php echo $i; ?>_window  door_height2">
                </td><td><img style="float: right;" src="/calculator/images/door.png" /></td></tr></table>
                <table><tr><td colspan="2">Дверь 3</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input kitchen_<?php echo $i; ?>_window  door_width3">
                  Высота(м): <input type="text" value="0" class="window_input kitchen_<?php echo $i; ?>_window  door_height3">
                </td><td><img style="float: right;" src="/calculator/images/door.png" /></td></tr></table>
                
              </div>
              <hr>
            <?php						
							foreach($kitchensWall as $k => $v)
								{
								echo '<div class="item">';
									echo '<img data-price="'.$v['price'].'" class="img_click img-kitchen'.$i.'-wall" alt="'.$v['service'].'" src="/calculator/images/'.$v['image'].'"/>';
									echo '<p><b>'.$v['service'].'</b></p>';								
									echo '<i>'.$v['description'].'</i>';									
								echo '</div>';
								}							
						echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</section>';
	echo '</div>';
	
// Дополнительно помещения
	echo '<div class="accordion">';
		echo '<section class="accordion_item">';
			echo '<div class="room-sub">';
				echo '<div class="room-top room-name title_block">Кухня '.$i.' - '.$kitchensAdd[0]['type'].'</div>';
				echo '<div class="info">';
					echo '<div class="room-top room'.$i.'-wall-text"></div>';
						echo '<div class="room-content">';							
							foreach($kitchensAdd as $k => $v)
								{
								// Показываем подтип для дополнительного
								if($k < 1){
									echo '<div class="subTitle">'.$v['sub_type'].'</div>';
									$tmp = $v['sub_type'];}
								if ($tmp != $v['sub_type']){
									$tmp = $v['sub_type'];
									echo '<div class="subTitle">'.$v['sub_type'].'</div>';}
									
								echo '<div class="item">';
									//echo '<img data-price="'.$v['price'].'" class="img-room'.$i.'-wall" alt="'.$v['service'].'" src="/calculator/images/'.$v['image'].'"/>';
									if ($v['control_id'] == 1) echo '<div class="img-add"><img data-price="'.$v['price'].'" class="img-kitchen'.$i.'-additional" alt="" src="/calculator/images/'.$v['image'].'"/><div class="img-add-but"><div class="minus">-</div><div class="digit digit-quantity">0</div><div class="plus">+</div></div></div>';
									if ($v['control_id'] == 2) echo '<div class="img-add"><img data-price="'.$v['price'].'" class="img-kitchen'.$i.'-additional" alt="" src="/calculator/images/'.$v['image'].'"/><div class="img-add-but"><input type="text" placeholder="'.$v['dimension'].'" class="digit_insert digit-quantity"></div></div>';
									if ($v['control_id'] == 3) echo '<div class="img-add"><img data-price="'.$v['price'].'" class="img_click from-square img-room'.$i.'-additional" alt="" src="/calculator/images/'.$v['image'].'"/><div style="display: none;" class="digit-quantity">0</div></div>';
									echo '<p><b>'.$v['service'].'</b></p>';								
									echo '<i>'.$v['description'].'</i>';									
								echo '</div>';
								}							
						echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</section>';
	echo '</div>';


// Блок Кухня конец
echo '</div>';
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// ЛОДЖИЯ
for ($i=1; $i <= $loggias_count ; $i++)
{
// Блок Лоджия старт
echo '<div class="eSquare1 loggia loggia-'.$i.'">';
// Главная строка помещения
	echo '<div class="top-string">';
		echo '<div class="room-top room-name">Лоджия '.$i.'</div>';
		echo '<div class="room-top ">Уточните площадь: <input type="text" value="10" class="eSquare2 loggia-square loggia'.$i.'-square">кв.м.</div>';
		echo '<div class="room-top ">Стоимость ремонта: <strong><div class="room-top loggia'.$i.'-cost">0</div>&#8381;</strong></div>';
	echo '</div>';


// Пол помещения
	echo '<div class="accordion">';
		echo '<section class="accordion_item">';
			echo '<div class="room-sub">';
				echo '<div class="room-top room-name title_block">Лоджия '.$i.' - '.$loggiasFloor[0]['type'].'</div>';
				echo '<div class="info">';
					echo '<div class="room-top room'.$i.'-floor-text"></div>';
						echo '<div class="room-content">';							
							foreach($loggiasFloor as $k => $v)
								{
								echo '<div class="item">';
									echo '<img data-price="'.$v['price'].'" class="img_click img-loggia'.$i.'-floor" alt="'.$v['service'].'" src="/calculator/images/'.$v['image'].'"/>';
									echo '<p><b>'.$v['service'].'</b></p>';								
									echo '<i>'.$v['description'].'</i>';									
								echo '</div>';
								}							
						echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</section>';
	echo '</div>';
	
// Потолок помещения
	echo '<div class="accordion">';
		echo '<section class="accordion_item">';
			echo '<div class="room-sub">';
				echo '<div class="room-top room-name title_block">Лоджия '.$i.' - '.$loggiasRoof[0]['type'].'</div>';
				echo '<div class="info">';
					echo '<div class="room-top room'.$i.'-roof-text"></div>';
						echo '<div class="room-content">';							
							foreach($loggiasRoof as $k => $v)
								{
								echo '<div class="item">';
									echo '<img data-price="'.$v['price'].'" class="img_click img-loggia'.$i.'-roof" alt="'.$v['service'].'" src="/calculator/images/'.$v['image'].'"/>';
									echo '<p><b>'.$v['service'].'</b></p>';								
									echo '<i>'.$v['description'].'</i>';									
								echo '</div>';
								}							
						echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</section>';
	echo '</div>';
	
// Cтены помещения
	echo '<div class="accordion">';
		echo '<section class="accordion_item">';
			echo '<div class="room-sub">';
				echo '<div class="room-top room-name title_block">Лоджия '.$i.' - '.$loggiasWall[0]['type'].'</div>';
				echo '<div class="info">';
					echo '<div class="room-top room'.$i.'-wall-text"></div>';
						echo '<div class="room-content">';			
            ?>
              <p align="center">Оконные и дверные проемы</p>
              <div class="window_block">
                <table><tr><td colspan="2">Окно 1</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input loggia_<?php echo $i; ?>_window window_width1">
                  Высота(м): <input type="text" value="0" class="window_input loggia_<?php echo $i; ?>_window window_height1">
                </td><td><img style="float: right;" src="/calculator/images/window.png" /></td></tr></table>
                <table><tr><td colspan="2">Окно 2</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input loggia_<?php echo $i; ?>_window window_width2">
                  Высота(м): <input type="text" value="0" class="window_input loggia_<?php echo $i; ?>_window  window_height2">
                </td><td><img style="float: right;" src="/calculator/images/window.png" /></td></tr></table>
                <table><tr><td colspan="2">Окно 3</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input loggia_<?php echo $i; ?>_window  window_width3">
                  Высота(м): <input type="text" value="0" class="window_input loggia_<?php echo $i; ?>_window  window_height3">
                </td><td><img style="float: right;" src="/calculator/images/window.png" /></td></tr></table>
                <table><tr><td colspan="2">Дверь 1</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input loggia_<?php echo $i; ?>_window  door_width1">
                  Высота(м): <input type="text" value="0" class="window_input loggia_<?php echo $i; ?>_window  door_height1">
                </td><td><img style="float: right;" src="/calculator/images/door.png" /></td></tr></table>
                <table><tr><td colspan="2">Дверь 2</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input loggia_<?php echo $i; ?>_window  door_width2">
                  Высота(м): <input type="text" value="0" class="window_input loggia_<?php echo $i; ?>_window  door_height2">
                </td><td><img style="float: right;" src="/calculator/images/door.png" /></td></tr></table>
                <table><tr><td colspan="2">Дверь 3</td></tr><tr><td>
                  Ширина(м): <input type="text" value="0" class="window_input loggia_<?php echo $i; ?>_window  door_width3">
                  Высота(м): <input type="text" value="0" class="window_input loggia_<?php echo $i; ?>_window  door_height3">
                </td><td><img style="float: right;" src="/calculator/images/door.png" /></td></tr></table>
                
              </div>
              <hr>
            <?php						
							foreach($loggiasWall as $k => $v)
								{
								echo '<div class="item">';
									echo '<img data-price="'.$v['price'].'" class="img_click img-loggia'.$i.'-wall" alt="'.$v['service'].'" src="/calculator/images/'.$v['image'].'"/>';
									echo '<p><b>'.$v['service'].'</b></p>';								
									echo '<i>'.$v['description'].'</i>';									
								echo '</div>';
								}							
						echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</section>';
	echo '</div>';
	
// Дополнительно помещения
	echo '<div class="accordion">';
		echo '<section class="accordion_item">';
			echo '<div class="room-sub">';
				echo '<div class="room-top room-name title_block">Лоджия '.$i.' - '.$loggiasAdd[0]['type'].'</div>';
				echo '<div class="info">';
					echo '<div class="room-top room'.$i.'-wall-text"></div>';
						echo '<div class="room-content">';							
							foreach($loggiasAdd as $k => $v)
								{
								// Показываем подтип для дополнительного
								if($k < 1){
									echo '<div class="subTitle">'.$v['sub_type'].'</div>';
									$tmp = $v['sub_type'];}
								if ($tmp != $v['sub_type']){
									$tmp = $v['sub_type'];
									echo '<div class="subTitle">'.$v['sub_type'].'</div>';}
									
								echo '<div class="item">';
									//echo '<img data-price="'.$v['price'].'" class="img-room'.$i.'-wall" alt="'.$v['service'].'" src="/calculator/images/'.$v['image'].'"/>';
									if ($v['control_id'] == 1) echo '<div class="img-add"><img data-price="'.$v['price'].'" class="img-loggia'.$i.'-additional" alt="" src="/calculator/images/'.$v['image'].'"/><div class="img-add-but"><div class="minus">-</div><div class="digit digit-quantity">0</div><div class="plus">+</div></div></div>';
									if ($v['control_id'] == 2) echo '<div class="img-add"><img data-price="'.$v['price'].'" class="img-loggia'.$i.'-additional" alt="" src="/calculator/images/'.$v['image'].'"/><div class="img-add-but"><input type="text" placeholder="'.$v['dimension'].'" class="digit_insert digit-quantity"></div></div>';
									if ($v['control_id'] == 3) echo '<div class="img-add"><img data-price="'.$v['price'].'" class="img_click from-square img-room'.$i.'-additional" alt="" src="/calculator/images/'.$v['image'].'"/><div style="display: none;" class="digit-quantity">0</div></div>';
									echo '<p><b>'.$v['service'].'</b></p>';								
									echo '<i>'.$v['description'].'</i>';									
								echo '</div>';
								}							
						echo '</div>';
				echo '</div>';
			echo '</div>';
		echo '</section>';
	echo '</div>';


// Блок Лоджия конец
echo '</div>';
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


?>				

	
				</div>
				<div class="spacing">&nbsp;</div>
				<div class="information-block">
					<p>Стоимость ремонта</p>
					<div class="price-full">0 &#8381;</div>
				</div>
			</div>
		</div>
	</body>
</html>
<script src="/calculator/js/accordeon.js"></script>
<script src="/calculator/js/scripts.js"></script>