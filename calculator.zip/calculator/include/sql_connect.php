<?php
function getRooms($room, $type)
	{
	$mysqli = mysqli_connect('mysql.bestfireball.myjino.ru', '045276242_palstr', 'UfSM}UX2Z@,S', 'bestfireball_pallada-stroy');
	if ($mysqli->connect_errno) echo "Не удалось подключиться к MySQL: " . $mysqli->connect_error;

	$sql = "SELECT * FROM calculator WHERE room = '".$room."' AND type = '".$type."' ORDER BY type DESC, sub_type ASC, ord ASC";
	//echo $sql; die;
	$res = $mysqli->query($sql);
	$res->data_seek(0);
	while ($row = $res->fetch_assoc()) 
		{
		$rooms[] = array('id' => $row['id'], 'type' => $row['type'], 'service' => $row['service'], 'price' => $row['price'], 'image' => $row['image'], 'control_id' => $row['control_id'], 'sub_type' => $row['sub_type'], 'dimension' => $row['dimension'], 'description' => $row['description']);
		}
	$rooms = array_values($rooms);
	return $rooms;
	}
?>